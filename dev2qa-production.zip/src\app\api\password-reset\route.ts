import { NextResponse } from 'next/server';
import { getAuth } from '@/lib/firebase-admin-simple';
import { sendCustomPasswordResetEmail } from '@/app/requests/actions';

export async function POST(request: Request) {
  try {
    const { email } = await request.json();

    if (!email) {
      return NextResponse.json({ message: 'Email is required' }, { status: 400 });
    }

    // Generate a password reset link using Firebase Admin SDK
    const auth = getAuth();
    const resetLink = await auth.generatePasswordResetLink(email);

    // Send our beautiful custom email
    const emailResult = await sendCustomPasswordResetEmail(email, resetLink);

    if (!emailResult.success) {
      return NextResponse.json({ 
        message: 'Failed to send password reset email', 
        error: emailResult.error 
      }, { status: 500 });
    }

    return NextResponse.json({ 
      message: 'Password reset email sent successfully' 
    });

  } catch (error: any) {
    console.error('Error in password reset:', error);
    
    // Handle specific Firebase Auth errors
    if (error.code === 'auth/user-not-found') {
      return NextResponse.json({ 
        message: 'No account found with this email address' 
      }, { status: 404 });
    }
    
    if (error.code === 'auth/invalid-email') {
      return NextResponse.json({ 
        message: 'Invalid email address' 
      }, { status: 400 });
    }

    return NextResponse.json({ 
      message: 'An error occurred while processing your request' 
    }, { status: 500 });
  }
}
