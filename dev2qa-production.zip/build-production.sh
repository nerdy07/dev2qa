#!/bin/bash

# Dev2QA Production Build Script for Hostinger
echo "🚀 Building Dev2QA for production deployment..."

# Check if .env.production exists
if [ ! -f ".env.production" ]; then
    echo "❌ Error: .env.production file not found!"
    echo "Please copy env.production.template to .env.production and fill in the values."
    exit 1
fi

# Copy production environment file
echo "📋 Setting up production environment..."
cp .env.production .env

# Install dependencies
echo "📦 Installing dependencies..."
npm ci --only=production

# Run type checking
echo "🔍 Running TypeScript type checking..."
npm run typecheck

if [ $? -ne 0 ]; then
    echo "❌ TypeScript errors found. Please fix them before building."
    exit 1
fi

# Run linting
echo "🧹 Running ESLint..."
npm run lint

# Build the application
echo "🔨 Building application for production..."
npm run build

if [ $? -eq 0 ]; then
    echo "✅ Build successful!"
    echo "📁 Production files are ready in the .next folder"
    echo "🚀 You can now deploy to Hostinger"
    
    # Create deployment package
    echo "📦 Creating deployment package..."
    tar -czf dev2qa-production.tar.gz \
        --exclude=node_modules \
        --exclude=.git \
        --exclude=.next/cache \
        --exclude=*.log \
        .
    
    echo "📦 Deployment package created: dev2qa-production.tar.gz"
    echo "📤 Upload this file to your Hostinger file manager"
else
    echo "❌ Build failed. Please check the errors above."
    exit 1
fi
