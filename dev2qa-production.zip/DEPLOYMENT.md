# 🚀 Dev2QA Hostinger Deployment Guide

## Overview
This guide will help you deploy Dev2QA to Hostinger at `dev2qa.echobitstech.com`.

## Prerequisites
- Hostinger hosting account with Node.js support
- Firebase project configured
- Brevo email service account
- Domain `dev2qa.echobitstech.com` pointed to Hostinger

## Step 1: Environment Configuration

### 1.1 Create Production Environment File
1. Copy `env.production.template` to `.env.production`
2. Fill in all the required values:

```bash
# Firebase Client SDK (from Firebase Console)
NEXT_PUBLIC_FIREBASE_API_KEY=your_actual_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=certitrack-fe7zw.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=certitrack-fe7zw
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=certitrack-fe7zw.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_firebase_app_id

# Firebase Admin SDK (Service Account JSON as single line)
FIREBASE_SERVICE_ACCOUNT_KEY={"type":"service_account",...}

# Brevo Email Service
BREVO_API_KEY=your_brevo_api_key
BREVO_SENDER_EMAIL=info@echobitstech.com
BREVO_SENDER_NAME=Dev2QA Certificate Management

# Production Domain
NEXT_PUBLIC_APP_URL=https://dev2qa.echobitstech.com
NEXT_PUBLIC_APP_NAME=Dev2QA
NODE_ENV=production
```

### 1.2 Firebase Configuration
1. Go to Firebase Console → Project Settings → General
2. Add your domain `dev2qa.echobitstech.com` to authorized domains
3. Download the service account key JSON file
4. Convert the JSON to a single line for the environment variable

## Step 2: Build for Production

### 2.1 Local Build Test
```bash
# Install dependencies
npm install

# Build the application
npm run build

# Test the build locally
npm start
```

### 2.2 Verify Build
- Check that all pages load correctly
- Test authentication flow
- Verify email functionality

## Step 3: Hostinger Deployment

### 3.1 Upload Files
1. Upload the entire project folder to your Hostinger file manager
2. Or use FTP/SFTP to upload to your domain's public_html folder

### 3.2 Set Environment Variables
1. In Hostinger control panel, go to "Advanced" → "Environment Variables"
2. Add all the environment variables from your `.env.production` file

### 3.3 Configure Node.js
1. In Hostinger control panel, go to "Node.js" section
2. Set Node.js version to 18.x or higher
3. Set the startup file to `server.js`
4. Set the application root to your project folder

### 3.4 Domain Configuration
1. Point your domain `dev2qa.echobitstech.com` to your Hostinger account
2. Configure SSL certificate (Let's Encrypt is free)
3. Set up redirects from HTTP to HTTPS

## Step 4: Post-Deployment Configuration

### 4.1 Firebase Authentication
1. Add `https://dev2qa.echobitstech.com` to authorized domains in Firebase Console
2. Update OAuth redirect URIs if using social login

### 4.2 Email Service
1. Verify Brevo sender email is verified
2. Test email sending functionality
3. Configure SPF/DKIM records for better deliverability

### 4.3 Security
1. Enable HTTPS redirect
2. Set up security headers (already configured in next.config.ts)
3. Configure firewall rules if available

## Step 5: Testing

### 5.1 Basic Functionality
- [ ] Homepage loads correctly
- [ ] Login/authentication works
- [ ] Dashboard loads for different user roles
- [ ] User creation works
- [ ] Email notifications are sent
- [ ] All forms submit correctly

### 5.2 Performance Testing
- [ ] Page load times are acceptable
- [ ] Images load correctly
- [ ] Mobile responsiveness works
- [ ] SSL certificate is valid

## Step 6: Monitoring & Maintenance

### 6.1 Error Monitoring
- Set up error logging
- Monitor application performance
- Check email delivery rates

### 6.2 Regular Maintenance
- Update dependencies regularly
- Monitor Firebase usage
- Check Brevo email quotas
- Backup database regularly

## Troubleshooting

### Common Issues

#### 1. Build Errors
```bash
# Clear cache and rebuild
rm -rf .next node_modules
npm install
npm run build
```

#### 2. Environment Variables Not Loading
- Check that variables are set in Hostinger control panel
- Restart the Node.js application
- Verify variable names match exactly

#### 3. Firebase Connection Issues
- Verify API keys are correct
- Check Firebase project settings
- Ensure domain is authorized

#### 4. Email Not Sending
- Verify Brevo API key
- Check sender email is verified
- Test with a simple email first

### Support
- Check Hostinger documentation for Node.js hosting
- Firebase support for authentication issues
- Brevo support for email delivery issues

## Production Checklist

- [ ] Environment variables configured
- [ ] Firebase project set up for production domain
- [ ] Brevo email service configured
- [ ] SSL certificate installed
- [ ] Domain pointing to Hostinger
- [ ] Application builds successfully
- [ ] All functionality tested
- [ ] Error monitoring set up
- [ ] Backup strategy in place

## Security Considerations

1. **Environment Variables**: Never commit `.env` files to version control
2. **Firebase Rules**: Ensure Firestore security rules are properly configured
3. **HTTPS**: Always use HTTPS in production
4. **API Keys**: Rotate API keys regularly
5. **Updates**: Keep dependencies updated for security patches

---

**Deployment Complete!** 🎉

Your Dev2QA application should now be live at `https://dev2qa.echobitstech.com`
